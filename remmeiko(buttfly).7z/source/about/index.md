---
title: 关于本站
date: 2020-04-19 12:58:56
type: "about"
---

## 神奇の沟通

- 沟通是<font color=red> **传递**</font> 沟通是<font color=red> **交流**</font>
- 沟通是<font color=red> **分享**</font> 沟通是<font color=red> **智慧**</font>
- 沟通是<font color=red> **友谊**</font> 沟通是<font color=red> **力量**</font>

" **<font color=chocolate>认识自我、超越自我</font>** " 是沟通的最高境界

- 当你在项目中感觉所要学习的人和事越来越多时，说明你在 **<font color=chocolate>成长</font>** 。
- 当你感觉要责怪的人和事越来越少时，说明你在 **<font color=chocolate>成熟</font>** 。
- 当你在项目中不断获得了友谊和朋友时，说明你将取得项目的 **<font color=chocolate>成功</font>** 。


## 联系我
CSDN：<a href="https://chocolate.blog.csdn.net/">https://chocolate.blog.csdn.net/</a>（CSDN认证博客专家）

微信公众号：小狮子前端Vue

一个不是只会写业务代码的前端攻城狮会带给你怎样的体会呢？

座右铭：学如逆水行舟，不进则退